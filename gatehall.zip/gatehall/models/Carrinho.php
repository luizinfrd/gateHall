<?php
class Carrinho {
    private PDO $db;

    public function __construct(Database $database) {
        $this->db = $database->getConnection();
    }

    public function adicionar($usuario_id, $ingresso_id, $qtd): bool {
        $sql = "INSERT INTO carrinho (id_usuario, id_ingresso, quantidade) VALUES (:uid, :iid, :qtd)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':uid'=>$usuario_id, ':iid'=>$ingresso_id, ':qtd'=>$qtd]);
    }

    public function listarPorUsuario($usuario_id): array {
        $sql = "SELECT c.*, i.nome_evento, i.preco FROM carrinho c JOIN ingresso i ON c.id_ingresso = i.id WHERE c.id_usuario = :uid";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':uid'=>$usuario_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}