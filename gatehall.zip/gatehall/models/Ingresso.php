<?php
class Ingresso {
    private PDO $db;

    public function __construct(Database $database) {
        $this->db = $database->getConnection();
    }

    public function listarTodos(): array {
        $sql = "SELECT * FROM ingresso";
        return $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    public function criar($nome, $desc, $data, $hora, $preco): bool {
        $sql = "INSERT INTO ingresso (nome_evento, descricao, data_evento, hora_evento, preco) VALUES (:n, :d, :dt, :hr, :p)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':n'=>$nome, ':d'=>$desc, ':dt'=>$data, ':hr'=>$hora, ':p'=>$preco]);
    }

    public function excluir($id): bool {
        $sql = "DELETE FROM ingresso WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id'=>$id]);
    }
}