<?php
class Auth {
    public static function isAdmin(): bool {
        return isset($_SESSION['user']['is_admin']) && $_SESSION['user']['is_admin'] == 1;
    }

    public static function check(): bool {
        return isset($_SESSION['user']);
    }
}