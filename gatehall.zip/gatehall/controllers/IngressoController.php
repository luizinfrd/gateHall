<?php
require_once '../models/Ingresso.php';
require_once '../config/Database.php';
session_start();

$db = new Database();
$ingresso = new Ingresso($db);

if ($_POST['action'] === 'comprar') {
    require_once '../models/Carrinho.php';
    $c = new Carrinho($db);
    $c->adicionar($_SESSION['user']['id'], $_POST['ingresso_id'], 1);
    header('Location: ../views/carrinho.php');
}
