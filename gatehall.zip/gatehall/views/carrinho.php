<?php
require_once '../config/Database.php';
require_once '../models/Carrinho.php';
session_start();
if (!isset($_SESSION['user'])) die('Acesso negado.');

$db = new Database();
$c = new Carrinho($db);
$itens = $c->listarPorUsuario($_SESSION['user']['id']);

$total = 0;
foreach ($itens as $item) {
    $subtotal = $item['preco'] * $item['quantidade'];
    $total += $subtotal;
    echo 'Evento: ' . $item['nome_evento'] . ' | Quantidade: ' . $item['quantidade'] . ' | Subtotal: R$ ' . number_format($subtotal, 2, ',', '.') . '<br>';
}
echo '<br><strong>Total: R$ ' . number_format($total, 2, ',', '.') . '</strong>';
?>
<a href="ingressos.php">Voltar</a>