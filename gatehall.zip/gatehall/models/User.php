<?php
class User {
    private PDO $db;

    public function __construct(Database $database) {
        $this->db = $database->getConnection();
    }

    public function register($nome, $email, $senha, $telefone): bool {
        $hash = password_hash($senha, PASSWORD_DEFAULT);
        $sql = "INSERT INTO usuario (nome, email, senha_hash, telefone, is_admin) VALUES (:nome, :email, :senha, :telefone, 0)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':nome'=>$nome, ':email'=>$email, ':senha'=>$hash, ':telefone'=>$telefone]);
    }

    public function login($email, $senha): ?array {
        $sql = "SELECT * FROM usuario WHERE email = :email";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':email'=>$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user && password_verify($senha, $user['senha_hash'])) {
            return $user;
        }
        return null;
    }
}