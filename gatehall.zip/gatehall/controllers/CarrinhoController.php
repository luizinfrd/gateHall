<?php
session_start();
require_once '../models/Carrinho.php';
require_once '../config/Database.php';

$db = new Database();
$carrinho = new Carrinho($db);

if ($_POST['action'] === 'adicionar') {
    $carrinho->adicionar($_SESSION['user']['id'], $_POST['id_ingresso'], $_POST['quantidade']);
    header('Location: ../views/carrinho.php');
}

if ($_POST['action'] === 'remover') {
    $carrinho->remover($_POST['id_carrinho']);
    header('Location: ../views/carrinho.php');
}

if ($_POST['action'] === 'finalizar') {
    $carrinho->limparPorUsuario($_SESSION['user']['id']);
    echo "Compra finalizada com sucesso! <a href='../views/ingressos.php'>Voltar</a>";
}
?>