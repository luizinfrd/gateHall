<?php
require_once '../config/Database.php';
require_once '../models/Ingresso.php';
session_start();
if (!$_SESSION['user']['is_admin']) die('Acesso negado.');

$db = new Database();
$ing = new Ingresso($db);
$lista = $ing->listarTodos();
?>
<h1>Administração de Ingressos</h1>
<a href="criar_ingresso.php">Criar novo ingresso</a><br><br>
<?php
foreach ($lista as $i) {
    echo $i['nome_evento'] . ' - R$ ' . number_format($i['preco'], 2, ',', '.') . ' <a href="../controllers/AdminController.php?action=excluir&id=' . $i['id'] . '">Excluir</a><br>';
}
?>
<a href="../public/logout.php">Logout</a>