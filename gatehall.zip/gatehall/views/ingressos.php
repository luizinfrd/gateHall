<?php
require_once '../config/Database.php';
require_once '../models/Ingresso.php';
session_start();
if (!isset($_SESSION['user'])) die('Acesso negado.');

$db = new Database();
$ing = new Ingresso($db);
$lista = $ing->listarTodos();
foreach ($lista as $i) {
?>
    <p><?= $i['nome_evento'] ?> - R$ <?= number_format($i['preco'], 2, ',', '.') ?>
        <form action="../controllers/IngressoController.php" method="POST">
            <input type="hidden" name="action" value="comprar">
            <input type="hidden" name="ingresso_id" value="<?= $i['id'] ?>">
            <button type="submit">Comprar</button>
        </form>
    </p>
<?php } ?>
<a href="carrinho.php">Carrinho</a>