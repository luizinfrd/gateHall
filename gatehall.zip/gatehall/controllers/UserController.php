<?php
require_once '../models/User.php';
require_once '../config/Database.php';
session_start();

$db = new Database();
$user = new User($db);

if ($_POST['action'] === 'login') {
    $u = $user->login($_POST['email'], $_POST['senha']);
    if ($u) {
        $_SESSION['user'] = $u;
        if ($u['is_admin']) {
            header('Location: ../views/admin.php');
        } else {
            header('Location: ../views/ingressos.php');
        }
    } else {
        echo "Login inválido!";
    }
}

if ($_POST['action'] === 'register') {
    $r = $user->register($_POST['nome'], $_POST['email'], $_POST['senha'], $_POST['telefone']);
    header('Location: ../views/login.php');
}
