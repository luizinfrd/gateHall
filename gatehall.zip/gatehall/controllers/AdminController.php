<?php
require_once '../models/Ingresso.php';
require_once '../config/Database.php';
session_start();

$db = new Database();
$ingresso = new Ingresso($db);

if (!$_SESSION['user']['is_admin']) die('Acesso negado.');

if ($_POST['action'] === 'criar') {
    $ingresso->criar($_POST['nome'], $_POST['descricao'], $_POST['data'], $_POST['hora'], $_POST['preco']);
    header('Location: ../views/admin.php');
}

if ($_GET['action'] === 'excluir') {
    $ingresso->excluir($_GET['id']);
    header('Location: ../views/admin.php');
}