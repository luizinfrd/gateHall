<form action="../controllers/UserController.php" method="POST">
    <input type="hidden" name="action" value="register">
    Nome: <input type="text" name="nome"><br>
    Email: <input type="email" name="email"><br>
    Senha: <input type="password" name="senha"><br>
    Telefone: <input type="text" name="telefone"><br>
    <button type="submit">Cadastrar</button>
</form>