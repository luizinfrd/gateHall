<form action="../controllers/UserController.php" method="POST">
    <input type="hidden" name="action" value="login">
    Email: <input type="email" name="email"><br>
    Senha: <input type="password" name="senha"><br>
    <button type="submit">Entrar</button>
</form>
<a href="register.php">Cadastrar</a>