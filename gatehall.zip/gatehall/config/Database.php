<?php
class Database {
    private PDO $pdo;

    public function __construct() {
        $dsn = "mysql:host=localhost;dbname=gatehall;charset=utf8mb4";
        $user = 'root';
        $pass = '';

        try {
            $this->pdo = new PDO($dsn, $user, $pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Erro: " . $e->getMessage());
        }
    }

    public function getConnection(): PDO {
        return $this->pdo;
    }
}