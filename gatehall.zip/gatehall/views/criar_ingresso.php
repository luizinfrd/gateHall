<form action="../controllers/AdminController.php" method="POST">
    <input type="hidden" name="action" value="criar">
    Nome: <input type="text" name="nome"><br>
    Descrição: <input type="text" name="descricao"><br>
    Data: <input type="date" name="data"><br>
    Hora: <input type="time" name="hora"><br>
    Preço: <input type="text" name="preco"><br>
    <button type="submit">Criar</button>
</form>
<a href="admin.php">Voltar</a>